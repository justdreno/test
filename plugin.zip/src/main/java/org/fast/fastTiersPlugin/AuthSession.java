package org.fast.fastTiersPlugin;

public class AuthSession {
    private AuthState state;
    private String tempPassword;

    public AuthSession(AuthState initialState) {
        this.state = initialState;
        this.tempPassword = null;
    }

    public AuthState getState() {
        return state;
    }

    public void setState(AuthState state) {
        this.state = state;
    }

    public String getTempPassword() {
        return tempPassword;
    }

    public void setTempPassword(String tempPassword) {
        this.tempPassword = tempPassword;
    }
}
