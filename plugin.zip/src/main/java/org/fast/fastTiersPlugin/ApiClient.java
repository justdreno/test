package org.fast.fastTiersPlugin;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

public class ApiClient {
    private final String baseUrl;
    private final String secret;
    private final HttpClient client;
    private final Gson gson;

    public ApiClient(String baseUrl, String secret) {
        // Ensure exact base URL format without trailing slash
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        this.secret = secret;
        this.client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        this.gson = new Gson();
    }

    public CompletableFuture<CheckResponse> checkAccount(String username) {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/auth/check?username=" + username))
                .header("Authorization", "Bearer " + secret)
                .GET()
                .build();

        return client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    if (response.statusCode() != 200) {
                        return new CheckResponse(false, false, "API Error: " + response.statusCode());
                    }
                    JsonObject json = gson.fromJson(response.body(), JsonObject.class);
                    boolean exists = json.has("exists") && json.get("exists").getAsBoolean();
                    boolean isPremium = json.has("isPremium") && json.get("isPremium").getAsBoolean();
                    return new CheckResponse(exists, isPremium, null);
                });
    }

    public CompletableFuture<AuthResponse> register(String username, String password) {
        JsonObject body = new JsonObject();
        body.addProperty("username", username);
        body.addProperty("password", password);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/auth/register"))
                .header("Authorization", "Bearer " + secret)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(body)))
                .build();

        return sendAuthRequest(request);
    }

    public CompletableFuture<AuthResponse> login(String username, String password) {
        JsonObject body = new JsonObject();
        body.addProperty("username", username);
        body.addProperty("password", password);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/auth/login"))
                .header("Authorization", "Bearer " + secret)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(body)))
                .build();

        return sendAuthRequest(request);
    }

    public CompletableFuture<AuthResponse> verify(String username, String code) {
        JsonObject body = new JsonObject();
        body.addProperty("username", username);
        body.addProperty("code", code);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/auth/verify"))
                .header("Authorization", "Bearer " + secret)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(body)))
                .build();

        return sendAuthRequest(request);
    }

    private CompletableFuture<AuthResponse> sendAuthRequest(HttpRequest request) {
        return client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    JsonObject json = gson.fromJson(response.body(), JsonObject.class);
                    if (response.statusCode() == 200) {
                        return new AuthResponse(true, null);
                    } else {
                        String error = json.has("error") ? json.get("error").getAsString() : "Unknown error";
                        return new AuthResponse(false, error);
                    }
                })
                .exceptionally(ex -> new AuthResponse(false, "Connection error: " + ex.getMessage()));
    }

    public static class CheckResponse {
        public final boolean exists;
        public final boolean isPremium;
        public final String error;

        public CheckResponse(boolean exists, boolean isPremium, String error) {
            this.exists = exists;
            this.isPremium = isPremium;
            this.error = error;
        }
    }

    public static class AuthResponse {
        public final boolean success;
        public final String error;

        public AuthResponse(boolean success, String error) {
            this.success = success;
            this.error = error;
        }
    }
}
