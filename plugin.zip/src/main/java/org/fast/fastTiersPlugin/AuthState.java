package org.fast.fastTiersPlugin;

public enum AuthState {
    WAITING_REGISTER_PASSWORD,
    WAITING_REGISTER_CONFIRM,
    WAITING_LOGIN,
    WAITING_VERIFY_CODE,
    AUTHENTICATED
}
