package org.fast.fastTiersPlugin;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class FastTiersPlugin extends JavaPlugin {

    private ApiClient apiClient;
    private final Map<UUID, AuthSession> authSessions = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        // Save default config if not exists
        saveDefaultConfig();

        String apiUrl = getConfig().getString("api-url", "http://localhost:3000");
        String apiSecret = getConfig().getString("api-secret", "YOUR_SECRET_HERE");

        this.apiClient = new ApiClient(apiUrl, apiSecret);

        // Register listeners
        getServer().getPluginManager().registerEvents(new AuthListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatInputHandler(this), this);

        getLogger().info("FastTiers Auth Plugin enabled.");
    }

    @Override
    public void onDisable() {
        authSessions.clear();
        getLogger().info("FastTiers Auth Plugin disabled.");
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setPlayerSession(Player player, AuthSession session) {
        authSessions.put(player.getUniqueId(), session);
    }

    public AuthSession getPlayerSession(Player player) {
        return authSessions.get(player.getUniqueId());
    }

    public void removePlayerSession(Player player) {
        authSessions.remove(player.getUniqueId());
    }

    public boolean isFrozen(Player player) {
        AuthSession session = getPlayerSession(player);
        return session != null && session.getState() != AuthState.AUTHENTICATED;
    }

    public void freezePlayer(Player player) {
        // Handled dynamically by isFrozen
    }

    public void unfreezePlayer(Player player) {
        AuthSession session = getPlayerSession(player);
        if (session != null) {
            session.setState(AuthState.AUTHENTICATED);
        }
    }
}
