package org.fast.fastTiersPlugin;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatInputHandler implements Listener {
    private final FastTiersPlugin plugin;

    public ChatInputHandler(FastTiersPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        AuthSession session = plugin.getPlayerSession(player);

        if (session == null || session.getState() == AuthState.AUTHENTICATED) {
            return; // Normal chat
        }

        event.setCancelled(true); // Always cancel so password/code isn't broadcasted
        String input = event.getMessage().trim();
        String username = player.getName();

        switch (session.getState()) {
            case WAITING_REGISTER_PASSWORD:
                session.setTempPassword(input);
                session.setState(AuthState.WAITING_REGISTER_CONFIRM);
                player.sendMessage(ChatColor.GOLD + "================================");
                player.sendMessage(ChatColor.YELLOW + "Please re-type your password to confirm.");
                player.sendMessage(ChatColor.GOLD + "================================");
                break;

            case WAITING_REGISTER_CONFIRM:
                if (!input.equals(session.getTempPassword())) {
                    session.setTempPassword(null);
                    session.setState(AuthState.WAITING_REGISTER_PASSWORD);
                    player.sendMessage(ChatColor.RED + "Passwords do not match!");
                    player.sendMessage(ChatColor.YELLOW + "Please enter your desired password again.");
                    break;
                }

                // Call register API
                player.sendMessage(ChatColor.YELLOW + "Registering account...");
                plugin.getApiClient().register(username, input).thenAcceptAsync(response -> {
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        if (!player.isOnline()) return;

                        if (response.success) {
                            player.kickPlayer("§aAccount created successfully!\n§7Please reconnect and login with your password.");
                        } else {
                            session.setTempPassword(null);
                            session.setState(AuthState.WAITING_REGISTER_PASSWORD);
                            player.sendMessage(ChatColor.RED + "Registration failed: " + response.error);
                            player.sendMessage(ChatColor.YELLOW + "Please try again. Enter a new password.");
                        }
                    });
                });
                break;

            case WAITING_LOGIN:
                player.sendMessage(ChatColor.YELLOW + "Logging in...");
                plugin.getApiClient().login(username, input).thenAcceptAsync(response -> {
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        if (!player.isOnline()) return;

                        if (response.success) {
                            player.sendMessage(ChatColor.GREEN + "Login successful!");
                            player.sendMessage(ChatColor.YELLOW + "Please enter your §b6-digit Discord Verification Code§e in chat.");
                            player.sendMessage(ChatColor.GRAY + "Need help? Click 'Set Profile & Get Role' on Discord.");
                            session.setState(AuthState.WAITING_VERIFY_CODE);
                        } else {
                            player.sendMessage(ChatColor.RED + "Login failed: " + response.error);
                            player.sendMessage(ChatColor.YELLOW + "Please try again. Enter your password.");
                        }
                    });
                });
                break;

            case WAITING_VERIFY_CODE:
                player.sendMessage(ChatColor.YELLOW + "Verifying code...");
                plugin.getApiClient().verify(username, input).thenAcceptAsync(response -> {
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        if (!player.isOnline()) return;

                        if (response.success) {
                            player.sendMessage(ChatColor.GREEN + "Verification successful! Welcome to FastTiers.");
                            session.setState(AuthState.AUTHENTICATED);
                            plugin.unfreezePlayer(player);
                            // Set verified data in plugin cache if needed
                        } else {
                            player.sendMessage(ChatColor.RED + "Verification failed: " + response.error);
                            player.sendMessage(ChatColor.YELLOW + "Please check your Discord DMs and enter the 6-digit code again.");
                        }
                    });
                });
                break;

            default:
                break;
        }
    }
}
