package org.fast.fastTiersPlugin;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class AuthListener implements Listener {
    private final FastTiersPlugin plugin;

    public AuthListener(FastTiersPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        String username = player.getName();

        // 1. Freeze the player by putting them in an initial state
        plugin.setPlayerSession(player, new AuthSession(AuthState.WAITING_VERIFY_CODE)); // Temp state until API returns
        plugin.freezePlayer(player);

        player.sendMessage(ChatColor.YELLOW + "Checking account status...");

        // 2. Call API asynchronously
        plugin.getApiClient().checkAccount(username).thenAcceptAsync(response -> {
            if (response.error != null) {
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    player.kickPlayer("§cAuth Server Offline / Error\n§7Please try again later.\n\n" + response.error);
                });
                return;
            }

            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;

                if (response.isPremium && !response.exists) {
                    // Premium player connecting for first time — auto create, skip to verify code
                    player.sendMessage(ChatColor.GREEN + "Premium account detected!");
                    player.sendMessage(ChatColor.YELLOW + "Please enter your §b6-digit Discord Verification Code§e in chat.");
                    player.sendMessage(ChatColor.GRAY + "Need help? Click 'Set Profile & Get Role' on Discord.");
                    plugin.setPlayerSession(player, new AuthSession(AuthState.WAITING_VERIFY_CODE));
                } else if (!response.exists) {
                    // Cracked - No account -> Register
                    player.sendMessage(ChatColor.GOLD + "========== " + ChatColor.AQUA + "FastTiers " + ChatColor.GOLD + "==========");
                    player.sendMessage(ChatColor.YELLOW + "Welcome! Please register an account.");
                    player.sendMessage(ChatColor.YELLOW + "Type your desired §bpassword§e in chat.");
                    player.sendMessage(ChatColor.GOLD + "================================");
                    player.sendMessage(ChatColor.GRAY + "Someone already registered this name? Open a ticket on Discord to claim it.");
                    plugin.setPlayerSession(player, new AuthSession(AuthState.WAITING_REGISTER_PASSWORD));
                } else {
                    // Account exists (Cracked or Premium) -> Login
                    player.sendMessage(ChatColor.GOLD + "========== " + ChatColor.AQUA + "FastTiers " + ChatColor.GOLD + "==========");
                    player.sendMessage(ChatColor.YELLOW + "Welcome back! Please login.");
                    player.sendMessage(ChatColor.YELLOW + "Type your §bpassword§e in chat.");
                    player.sendMessage(ChatColor.GOLD + "================================");
                    plugin.setPlayerSession(player, new AuthSession(AuthState.WAITING_LOGIN));
                }
            });
        });
    }

    // --- Prevent interactions while frozen ---

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (plugin.isFrozen(event.getPlayer())) {
            if (event.getFrom().getX() != event.getTo().getX() || event.getFrom().getZ() != event.getTo().getZ() || event.getFrom().getY() < event.getTo().getY()) {
                event.setTo(event.getFrom());
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (plugin.isFrozen(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        if (plugin.isFrozen(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();
            if (plugin.isFrozen(player)) {
                event.setCancelled(true);
            }
        }
    }
}
